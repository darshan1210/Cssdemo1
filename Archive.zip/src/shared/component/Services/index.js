import React from 'react'
import './services.css'
function Services () {
  return (
        <>
            <div className='Services'>
                <div className='ServicesCard'>
                    <div className='ServicesCardNumber'>
                        992 <sup>+</sup>
                    </div>
                    <div className='ServicesCardDiscription'>
                        The standard chunk of Lorem lpsum used since the 1500s is reproduced below for those
                    </div>
                </div>
            </div>
        </>
  )
}

export default Services
