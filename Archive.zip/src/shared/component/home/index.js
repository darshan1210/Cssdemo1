import React from 'react'
import './Home.css'

function Home () {
  return (
        <>
            <div className='home'>
                <div className='home_heading'>
                <div className='home_heading1'>Agency.</div>
                <div className='home_heading2'> There are many variations of passages but the majority <br/> have suffered alteration.</div>
               <div className='home_btn'>
               <button >Contact Us</button>
               </div>
                </div>

            </div>
        </>
  )
}

export default Home
